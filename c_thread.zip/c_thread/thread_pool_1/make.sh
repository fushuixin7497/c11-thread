g++ -D__SOLA_LOGGING_ENABLED example.cpp thread_pool.cpp -o test.out -lpthread
