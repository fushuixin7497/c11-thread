#include"ThreadPool.h"
int main()
{
	{
		ThreadPool threadPool;
		threadPool.start();

		getchar();
	}

	getchar();

	return 0;
}