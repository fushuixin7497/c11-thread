#include <iostream>
#include <thread>
#include <string>

using namespace std;

//void myprint(const int i, const string pmybuf)
//{
//	cout << i << endl;
//	cout << pmybuf.c_str() << endl;
//	return;
//}
//
//
//int main() {
//
//	int mvar = 1;
//	int &mvary = mvar;
//
//	char mybuf[] = "this is a test!";
//	string haha = "hello world";
//
//	thread mytobj(myprint, mvar, haha); // ����mybuf��������ʲôʱ��ת����string�ģ�
//
//	mytobj.detach();
//	cout << "I Love China!" << endl;
//	return 0;
//}


#include <iostream>
#include <thread>
using namespace std;

void func()
{
	for (int i = -10; i > -20; i--)
	{
		cout << "from func():" << i << endl;
	}
}

int main()			//���߳�
{
	thread t(func);	//���߳�
	cout << "mian()" << endl;
	cout << "mian()" << endl;
	cout << "mian()" << endl;
	t.detach();		//�������߳�
	return 0;
}
